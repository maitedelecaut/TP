# Projet-agile-

L'équipe 7 à choisis de créer un Monopoly dans le cadre de notre mini-projet agile de S3. 
